import robin_stocks as r
import pandas as pd
import pyotp
import time
import argparse
import library.config as ConfigHandler

if __name__== '__main__':
    parser = argparse.ArgumentParser(description="Robo trading for Robinhood accounts")

    ConfigHandler.set_access('Robinhood')
    username = ConfigHandler.global_var.user_id
    password = ConfigHandler.global_var.user_password
    opt_code = ConfigHandler.global_var.user_opt_key

    totp  = pyotp.TOTP(opt_code).now()
    print("Current OTP:", totp)

    login = r.login(username,password, mfa_code=totp)

    result = r.build_holdings()
    print(result)
