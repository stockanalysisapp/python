#https://openpyxl.readthedocs.io/en/stable/

__all__ = ['user_id', 'user_password', 'user_opt_key']

stock_broker = None
user_id = None
user_password = None
user_opt_key = None

