from . import global_var
import json

__all__ = ['load_settings', 'settings', 'set_access']

def set_access(broker_name):
    global_var.stock_broker = broker_name
    env_var = settings('login')

    if broker_name == 'Robinhood':
        global_var.user_id = env_var[broker_name]['id']
        global_var.user_password = env_var[broker_name]['password']
        global_var.user_opt_key = env_var[broker_name]['opt_key']

def load_settings(env):
    # assume file name is <env>.json
    with open(f'{env}.json') as f:
        settings = json.load(f)
    return settings

def settings(env):
    common_settings = load_settings(env)
    return common_settings
    # combine common.json and <env>.json, with env settings taking precedence
    #env_settings = load_settings(env)
    #return ChainMap(env_settings, common_settings)