#https://openpyxl.readthedocs.io/en/stable/

import logging
from openpyxl import Workbook, load_workbook

__all__ = ['excel_handler', 'write_workbook', 'read_workbook', 'read_one_click_vm_list']

def write_workbook(path, row):
    pass

def read_one_click_vm_list(path):
    pass

def read_workbook(path):
    pass

def excel_handler(log_file):
    pass
