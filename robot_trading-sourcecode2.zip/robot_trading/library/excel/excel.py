#https://openpyxl.readthedocs.io/en/stable/

import logging
from openpyxl import Workbook, load_workbook
from tkinter import messagebox

__all__ = ['excel_handler', 'write_workbook', 'read_workbook']

def write_workbook(path, row, memo):
    wb_obj = load_workbook(path)
    sheet_obj = wb_obj.active
    c = sheet_obj.cell(row, column=3)
    c.value = '0'
    c = sheet_obj.cell(row, column=5)
    c.value = memo
    try:
        wb_obj.save(path)
    except Exception as e:
        messagebox.showerror(title='Please close the excel file', message=e)

def read_workbook(path):
    wb_obj = load_workbook(path)
    sheet_obj = wb_obj.active
    d = {}
    max_row = sheet_obj.max_row + 1
    for i in range(2, max_row):
        stock_ticker = sheet_obj.cell(row=i, column=1).value
        if stock_ticker:
            stock_ticker = stock_ticker.encode().decode('latin1')

        trade_type = sheet_obj.cell(row=i, column=2).value
        if trade_type:
            trade_type = trade_type.encode().decode('latin1')

        quantity = sheet_obj.cell(row=i, column=3).value
        target_price = sheet_obj.cell(row=i, column=4).value

        if stock_ticker is None or \
            trade_type is None or \
            quantity is None or \
            target_price is None:
            continue
        d[i] = {'stock_ticker': stock_ticker, 'trade_type': trade_type, 'quantity': quantity, 'target_price': target_price}    

    return d

def excel_handler(log_file):
    pass
