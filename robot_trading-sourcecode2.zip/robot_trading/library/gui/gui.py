import tkinter as tk
import os
from tkinter import Tk, Label, Button, StringVar, W, Entry, Listbox, filedialog, ttk, messagebox
from tkinter.ttk import Progressbar
import library.excel as ExcelHandler
import robin_stocks as r
from datetime import datetime

__all__ = ['MainApplication']

class MainApplication(tk.Frame):
    def __init__(self, master):
        self.master = master
        tk.Frame.__init__(self, self.master)

        self.start_stop_button = None
        self.filename = None
        self.current_stock = StringVar() 
        self.e1 = Entry(master)
        self.configure_gui()
        self.stock_list = {}
        self.tree = None
        self.start_trading = False
        self.scheduled_event = self.after(1000, self.background_task)

        #my_stocks = r.build_holdings()
        #print(my_stocks)

    def create_treeview_from_excel(self):
        self.tree = ttk.Treeview(self.master, selectmode='browse')
        self.tree.grid(row = 3, column = 0, columnspan=3, sticky='nsew')
        #self.tree.wait_visibility()
        vsb = ttk.Scrollbar(self.master, orient="vertical", command=self.tree.yview)
        vsb.grid(row=3, column=3, sticky='nsw')
        
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree["columns"] = ("1", "2", "3", "4", "5", "6", "7")
        self.tree['show'] = 'headings'
        self.tree.column("1", width=60, anchor='c', stretch=True)
        self.tree.column("2", width=60, anchor='c', stretch=True)
        self.tree.column("3", width=60, anchor='c', stretch=True)
        self.tree.column("4", width=60, anchor='c', stretch=True)
        self.tree.column("5", width=60, anchor='c', stretch=True)
        self.tree.column("6", width=60, anchor='c', stretch=True)
        self.tree.column("6", width=130, anchor='c', stretch=True)
        self.tree.column("7", width=30, anchor='c', stretch=True)
        self.tree.heading("1", text="Stock Ticker")
        self.tree.heading("2", text="Sell/Buy")
        self.tree.heading("3", text="Quantity")
        self.tree.heading("4", text="Current Price")
        self.tree.heading("5", text="Target Price")
        self.tree.heading("6", text="Status")
        self.tree.heading("7", text="Processed")

        processed_ticker = {}           
        for _, item  in self.stock_list.items():
            current_price = None
            status = 'Pending'
            ticker = item['stock_ticker']
            try:
                if ticker not in processed_ticker:
                    #print(ticker)
                    result = r.stocks.get_latest_price(ticker)[0]
                    if result is not None:
                        current_price = round(float(result), 2)
                    else:
                        current_price = None
                        status = 'Ticker Not Found'                        
                    #print(result)
                    processed_ticker[ticker] = current_price
                else:
                    current_price = processed_ticker[ticker]
            except:
                pass

            self.tree.insert("",'end',text="L1",values=(
                item['stock_ticker'],
                item['trade_type'],
                item['quantity'],
                current_price,
                item['target_price'],
                status,
                'No'
                ))
        self.start_stop_button = Button(self.master, text = "Start Trading", command = self.startTrading, bg="red")
        self.start_stop_button.grid(column = 0, row = 4, columnspan=3, sticky='nsew')

    def background_task(self):
        if self.start_stop_button and self.start_trading is True:
            now = datetime.now()
            current_time = now.strftime("%H:%M:%S")
            self.start_stop_button['text'] = "Stop Trading (last updated: " + current_time + ")"

        processed_ticker = {}
        row_cnt = 1
        if self.tree is not None:
            for each in self.tree.get_children():
                row_cnt += 1
                each_value = self.tree.item(each)['values']
                if each_value[3] == 'None':
                    continue
                
                quantity = float(each_value[2])
                current_price = float(each_value[3])
                target_price = float(each_value[4])
                current_ticker = each_value[0]

                if current_ticker not in processed_ticker:
                    current_price = round(float(r.stocks.get_latest_price(current_ticker)[0]), 2)
                    processed_ticker[current_ticker] = current_price
                    each_value[3] = current_price
                else:
                    current_price = processed_ticker[current_ticker]
                    each_value[3] = current_price

                action_type = each_value[1]
                processed = each_value[6]
                if quantity > 0 and self.start_trading is True and processed == 'No':
                    processed_log = 'Limit ' + action_type + ' ' + str(quantity) + ' shares of ' + current_ticker + ' at ' + str(current_price)
                    if action_type == 'Buy':
                        if target_price >= current_price:
                            MsgBox = messagebox.askquestion ('Limit Buy ' + str(target_price), processed_log, icon = 'warning')
                            if MsgBox == 'yes':
                                r.order_buy_limit(current_ticker, quantity, target_price)
                            else:
                                processed_log = 'Not Approved'
                            each_value[5] = processed_log
                            each_value[6] = 'Yes'                                
                            ExcelHandler.write_workbook(self.filename, row_cnt, processed_log)

                    elif action_type == 'Sell':
                        if target_price <= current_price:
                            MsgBox = messagebox.askquestion ('Limit Sell ' + str(target_price),processed_log, icon = 'warning')
                            if MsgBox == 'yes':
                                r.order_sell_limit(current_ticker, quantity, target_price)
                            else:
                                processed_log = 'Not Approved'
                            each_value[5] = processed_log
                            each_value[6] = 'Yes'                                
                            ExcelHandler.write_workbook(self.filename, row_cnt, processed_log)

                self.tree.item(each, values = each_value)
                #print(self.tree.item(each)['values'])
        self.scheduled_event = self.after(1000, self.background_task)        

    def startTrading(self):
        self.start_trading = True
        self.start_stop_button = Button(self.master, text = "Stop Trading", command = self.stopTrading, bg="blue", fg='white')
        self.start_stop_button.grid(column = 0, row = 4, columnspan=3, sticky='nsew') 

    def stopTrading(self):
        self.start_trading = False
        self.start_stop_button = Button(self.master, text = "Start Trading", command = self.startTrading, bg="red")
        self.start_stop_button.grid(column = 0, row = 4, columnspan=3, sticky='nsew')

    def browseFiles(self): 
        self.filename = filedialog.askopenfilename(initialdir = os.getcwd(), 
                                            title = "Select a File", 
                                            filetypes = (("Excel files", 
                                                            "*.xlsx*"), 
                                                        ("all files", 
                                                            "*.*"))) 
        # Change label contents
        if self.filename:
            self.label_file_explorer.configure(text="File Opened: " + self.filename)

        self.start_trading = False
        self.stock_list = ExcelHandler.read_workbook(self.filename)
        self.create_treeview_from_excel()

    def exit(self):
        self.master.destroy()
   
    def configure_gui(self):
        '''
        Label(self.master, text="Company Symbol : ").grid(row=0, sticky=W) 
        Label(self.master, text="Stock Result:").grid(row=3, sticky=W) 
        Label(self.master, text="", textvariable=self.current_stock,).grid(row=3, column=1, sticky=W)
        self.e1.grid(row=0, column=1) 
        b = Button(self.master, text="Show", command=self.stock_price) 
        b.grid(row=0, column=2, columnspan=2, rowspan=2, padx=5, pady=5)         
        '''
        self.label_file_explorer = Label(self.master,  
                            text = "Select an excel file", 
                            fg = "blue")
        self.label_file_explorer.grid(column = 0, row = 0) 
        Button(self.master, text = "Browse Files", command = self.browseFiles).grid(column = 1, row = 0, sticky='e') 
        Button(self.master,  text = "Exit", command = self.exit).grid(column = 2,row = 0, sticky='w')