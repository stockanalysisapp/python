import robin_stocks as r
import pyotp
import time
import argparse
import library.config as ConfigHandler
import library.excel as ExcelHandler
from library.gui import MainApplication
import tkinter as tk
import os
import keyring
from keyring.backends import Windows
import winreg
from tkinter import Tk, Label, Button, StringVar, W, Entry, Listbox, filedialog, ttk, messagebox, IntVar, Checkbutton
from functools import partial

REG_PATH = r"SOFTWARE\RobotTrading\Settings"

def set_reg(name, value):
    try:
        winreg.CreateKey(winreg.HKEY_CURRENT_USER, REG_PATH)
        registry_key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, REG_PATH, 0, 
                                       winreg.KEY_WRITE)
        winreg.SetValueEx(registry_key, name, 0, winreg.REG_SZ, value)
        winreg.CloseKey(registry_key)
        return True
    except WindowsError:
        return False

def get_reg(name):
    try:
        registry_key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, REG_PATH, 0,
                                       winreg.KEY_READ)
        value, _ = winreg.QueryValueEx(registry_key, name)
        winreg.CloseKey(registry_key)
        return value
    except WindowsError:
        return None

def validateLogin(username, password, opt_code, remember_login, loginRoot):
    username = username.get()
    password = password.get()
    opt_code = opt_code.get()

    '''
    ConfigHandler.set_access('Robinhood')
    username = ConfigHandler.global_var.user_id
    password = ConfigHandler.global_var.user_password
    opt_code = ConfigHandler.global_var.user_otp_key
    '''

    home_dir = os.path.expanduser("~")
    data_dir = os.path.join(home_dir, ".tokens")
    creds_file = "robinhood.pickle"
    pickle_path = os.path.join(data_dir, creds_file)
    if os.path.isfile(pickle_path):
	    os.remove(pickle_path)
    totp  = pyotp.TOTP(opt_code).now()

    try:
        r.login(username, password, mfa_code=totp)
    except Exception as e:
        messagebox.showerror(title='Login Error', message=e)
        return None

    remember_login = str(remember_login.get())
    if remember_login == '1':
        try:
            keyring.set_password("robot-trading", username, password)
            keyring.set_password("robot-trading-code", username, opt_code)
            #print("password stored successfully")
        except keyring.errors.PasswordSetError:
            print("failed to store password")
        set_reg('username', username)

    set_reg('remember_login', remember_login)
    loginRoot.destroy()

    root = tk.Tk()
    root.title("Robot Trading")
    root.wm_geometry("800x400")
    root.columnconfigure(0, weight=1)
    root.rowconfigure(3, weight=1)
    #root.resizable(0,0)
    MainApplication(root)
    root.mainloop()

def LoginPage():
    #window
    tkWindow = Tk()  
    tkWindow.geometry('220x120')  
    tkWindow.title('Robinhood Login')

    remember_login = get_reg('remember_login')
    username, password, otp_code = None, None, None
    if remember_login == '1':
        username = get_reg('username')
        password = keyring.get_password("robot-trading", username)
        otp_code = keyring.get_password("robot-trading-code", username)

    #username label and text entry box
    Label(tkWindow, text="User Name").grid(row=0, column=0)
    username = StringVar(value=username)
    Entry(tkWindow, textvariable=username).grid(row=0, column=1)  

    #password label and password entry box
    Label(tkWindow,text="Password").grid(row=1, column=0)  
    password = StringVar(value=password)
    Entry(tkWindow, textvariable=password, show='*').grid(row=1, column=1)  

    Label(tkWindow,text="OTP Key").grid(row=2, column=0)  
    otp_key = StringVar(value=otp_code)
    Entry(tkWindow, textvariable=otp_key, show='*').grid(row=2, column=1)

    remember_login = IntVar()
    remember_login.set(1)
    checkbutton = Checkbutton(tkWindow, text = "Remember Credentials", variable = remember_login)
    checkbutton.grid(row=4, column=0, columnspan=2)

    validateLogin_func = partial(validateLogin, username, password, otp_key, remember_login, tkWindow)

    #login button
    Button(tkWindow, text="Login", command=validateLogin_func).grid(row=5, column=0, columnspan=2, sticky='nsew')
    tkWindow.mainloop()

if __name__== '__main__':
    parser = argparse.ArgumentParser(description="Robo trading for Robinhood accounts")
    keyring.set_keyring(Windows.WinVaultKeyring())
    LoginPage()
